import os
import sys
from os import walk
from os.path import join as join_path
from threading import *

from PyQt5 import QtCore
from PyQt5.QtCore import QSize, Qt, QRect, QPoint, QEvent, pyqtSlot
from PyQt5.QtGui import QPixmap, QFontDatabase, QFont, QCursor, QPainter, QColor, QBrush, QResizeEvent
from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QPushButton, QVBoxLayout, QSizePolicy, QLayout, QScrollArea, \
    QFileDialog, QHBoxLayout, QFrame, QCheckBox, QMessageBox

import font_resources_rc


class FlowLayout(QLayout):
    def __init__(self, parent=None, margin=0, spacing=-1):
        super().__init__(parent)

        if parent is not None:
            self.setContentsMargins(margin, margin, margin, margin)

        self.setSpacing(spacing)

        self.itemList = []

    def __del__(self):
        item = self.takeAt(0)
        while item:
            item = self.takeAt(0)

    def addItem(self, item):
        self.itemList.append(item)

    def count(self):
        return len(self.itemList)

    def itemAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList[index]

        return None

    def takeAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList.pop(index)

        return None

    def expandingDirections(self):
        return Qt.Orientations(Qt.Orientation(0))

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        height = self.doLayout(QRect(0, 0, width, 0), True)
        return height

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self.doLayout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()

        for item in self.itemList:
            size = size.expandedTo(item.minimumSize())

        margin, _, _, _ = self.getContentsMargins()

        size += QSize(2 * margin, 2 * margin)
        return size

    def doLayout(self, rect, testOnly):
        x = rect.x()
        y = rect.y()
        lineHeight = 0

        for item in self.itemList:
            wid = item.widget()
            spaceX = self.spacing() + wid.style().layoutSpacing(QSizePolicy.PushButton, QSizePolicy.PushButton,
                                                                Qt.Horizontal)
            spaceY = self.spacing() + wid.style().layoutSpacing(QSizePolicy.PushButton, QSizePolicy.PushButton,
                                                                Qt.Vertical)
            nextX = x + item.sizeHint().width() + spaceX
            if nextX - spaceX > rect.right() and lineHeight > 0:
                x = rect.x()
                y = y + lineHeight + spaceY
                nextX = x + item.sizeHint().width() + spaceX
                lineHeight = 0

            if not testOnly:
                item.setGeometry(QRect(QPoint(x, y), item.sizeHint()))

            x = nextX
            lineHeight = max(lineHeight, item.sizeHint().height())

        return y + lineHeight - rect.y()


class App(QWidget):
    def __init__(self):
        super().__init__()

        # init variable start
        self.similar_images = None
        self.images_to_be_removed = []
        self.images = []
        self.imageItems = []
        self.group = 0
        self.check_resize_flag = False
        self.main_image_size = [0, 0]
        self.main_image_name = ''
        self.main_image_last_size = [0, 0]

        # init font
        font_id = QFontDatabase.addApplicationFont(":/Roboto.ttf")
        font = QFontDatabase.applicationFontFamilies(font_id)[0]
        self.font = QFont(font)

        # init styles
        file = QtCore.QFile("qt.qss")
        file.open(QtCore.QFile.ReadOnly | QtCore.QFile.Text)
        stream = QtCore.QTextStream(file)
        self.setStyleSheet(stream.readAll())

        # configuring main
        self.setObjectName("main")
        self.setWindowTitle("Image Utility")
        self.main = QVBoxLayout(self)

        # first screen
        self.first_screen = QWidget()
        self.main.addWidget(self.first_screen, alignment=Qt.AlignCenter)
        self.first_screen_layout = QVBoxLayout(self.first_screen)

        self.logoLabel = QLabel()
        self.logoLabel.setObjectName("logo")
        self.logo = QPixmap()
        self.logo.load("robotix.png")
        self.logo = self.logo.scaled(900, 160, aspectRatioMode=Qt.KeepAspectRatio)
        self.logoLabel.setPixmap(self.logo)
        self.first_screen_layout.addWidget(self.logoLabel, alignment=Qt.AlignHCenter | Qt.AlignBottom)

        self.chooseDirBtn = QPushButton("Выберите папку")
        self.chooseDirBtn.setObjectName("chooseDirBtn")
        print(self.font.family())
        self.first_screen_layout.addWidget(self.chooseDirBtn, alignment=Qt.AlignHCenter | Qt.AlignTop)
        self.chooseDirBtn.clicked.connect(self.choose_dir)

        # processing screen
        self.processing_screen = QWidget()
        self.processing_screen.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.processing_screen_layout = QVBoxLayout(self.processing_screen)
        self.status = QLabel('Обработка изображений')
        self.status.setStyleSheet('font-size: 28px;')
        self.processing_screen_layout.addWidget(self.status, alignment=Qt.AlignCenter)
        self.main.addWidget(self.processing_screen)
        self.processing_screen.hide()

        # images screen
        self.images_screen = QWidget()
        self.images_screen.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.images_screen_layout = QVBoxLayout(self.images_screen)
        self.images_screen.setObjectName("imagesScreen")

        self.group_num_lbl = QLabel('1 группа')
        self.group_num_lbl.setObjectName("groupNumLabel")
        self.images_screen_layout.addWidget(self.group_num_lbl)

        self.images_container = QWidget()
        self.images_container.setObjectName("imagesContainer")
        self.flowLayout = FlowLayout()
        self.images_container.setLayout(self.flowLayout)

        self.scroll = QScrollArea()
        self.scroll.setObjectName("scroll")
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setWidgetResizable(True)
        self.scroll.setWidget(self.images_container)
        self.images_screen_layout.addWidget(self.scroll)

        self.toggle_group_btn_container = QWidget()
        self.toggle_group_btn_container_layout = QHBoxLayout(self.toggle_group_btn_container)
        self.previous_group_btn = QPushButton()
        self.previous_group_btn.setObjectName("changeGroupBtn")
        self.previous_group_btn.setStyleSheet("background-image: url('left.png')")
        self.previous_group_btn.setCursor(QCursor(Qt.PointingHandCursor))
        self.previous_group_btn.clicked.connect(lambda event: widget.show_group(widget.group - 1))
        self.next_group_btn = QPushButton()
        self.next_group_btn.setObjectName("changeGroupBtn")
        self.next_group_btn.setStyleSheet("background-image: url('right.png')")
        self.next_group_btn.setCursor(QCursor(Qt.PointingHandCursor))
        self.next_group_btn.clicked.connect(lambda event: widget.show_group(widget.group + 1))
        self.delete_selected_btn = QPushButton("Удалить выбранные")
        self.delete_selected_btn.setStyleSheet("font-size: 24px;background-color: #00000000;background-repeat: no-repeat;height: 64px;padding: 0;margin: 0;")
        self.delete_selected_btn.setCursor(QCursor(Qt.PointingHandCursor))
        self.delete_selected_btn.clicked.connect(self.delete_selected)
        self.images_screen_layout.addWidget(self.toggle_group_btn_container)
        self.main.addWidget(self.images_screen)
        self.images_screen.hide()

        # show big image
        self.main_image_lbl_container = QWidget(self)
        self.main_image_lbl_container.setStyleSheet('background: #bb555555')
        self.main_image_lbl_container.setGeometry(self.main.geometry())
        self.main_image_lbl_container_layout = QVBoxLayout(self.main_image_lbl_container)
        self.main_image_lbl = QLabel()
        self.main_image_lbl_container.hide()
        self.main_image_lbl_container_layout.addWidget(self.main_image_lbl, alignment=Qt.AlignCenter)
        self.main_image_close = QPushButton(self.main_image_lbl_container)
        self.main_image_close.setObjectName('changeGroupBtn')
        self.main_image_close.setStyleSheet("background-color: #33777777;background-image: url('close.png');border-radius: 37px;background-repeat: no-repeat;background-position: center;")
        self.main_image_close.clicked.connect(self.close_big_image)

    def close_big_image(self):
        widget.main_image_lbl_container.hide()
        widget.check_resize_flag = False

    def thread(fn):
        def wrapper(*args, **kwargs):
            thread = Thread(target=fn, args=args, kwargs=kwargs)
            thread.start()
            return thread

        return wrapper

    def choose_dir(self):
        dir_name = QFileDialog.getExistingDirectory(self, "Выбрать папку", ".")
        self.first_screen.hide()
        self.processing_screen.show()
        self.job(dir_name)

    @thread
    def job(self, dir_name):
        self.find_similary(dir_name, test=False)
        self.processing_screen.hide()
        self.images_screen.show()
        self.show_group(0)

    def show_group(self, group):
        for i in reversed(range(self.toggle_group_btn_container_layout.count())):
            self.toggle_group_btn_container_layout.itemAt(i).widget().setParent(None)
        for i in self.imageItems:
            self.flowLayout.removeWidget(i[0])
        self.images = []
        self.imageItems = []

        if group > 0:
            self.toggle_group_btn_container_layout.addWidget(self.previous_group_btn, alignment=Qt.AlignLeft)
            self.previous_group_btn.setEnabled(False)

        if group < len(self.similar_images) - 1:
            self.toggle_group_btn_container_layout.addWidget(self.next_group_btn, alignment=Qt.AlignRight)
            self.next_group_btn.setEnabled(False)
        else:
            self.toggle_group_btn_container_layout.addWidget(self.delete_selected_btn, alignment=Qt.AlignRight)
            self.delete_selected_btn.setEnabled(False)

        self.group = group
        self.group_num_lbl.setText(f'Группа {group + 1} из {len(self.similar_images)}')
        print(f'\ngroup №{group}')
        group = self.similar_images[list(self.similar_images.keys())[group]]
        print(group)
        i = 0
        for j in range(len(group)):
            print('started adding...')
            self.imageItems.append([QWidget()])
            self.imageItems[i].append(QVBoxLayout(self.imageItems[i][0]))

            radius = 15
            pixmap = QPixmap()
            pixmap.load(group[j])
            pixmap = pixmap.scaled(900, 300, aspectRatioMode=Qt.KeepAspectRatio)
            rounded = QPixmap(pixmap.size())
            rounded.fill(QColor("transparent"))
            painter = QPainter(rounded)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(QBrush(pixmap))
            painter.setPen(QtCore.Qt.NoPen)
            painter.drawRoundedRect(pixmap.rect(), radius, radius)
            self.images.append(rounded)

            self.imageItems[i].append(QLabel())
            self.imageItems[i].append(QCheckBox(self.imageItems[i][2]))

            self.imageItems[i][2].setPixmap(self.images[i])
            self.imageItems[i][1].addWidget(self.imageItems[i][2])
            self.imageItems[i].append(QWidget(self.imageItems[i][0]))
            self.imageItems[i][4].mouseReleaseEvent = eval(
                f'lambda event: widget.click_on_image("{group[j]}", {i}, event)')
            self.imageItems[i][4].setCursor(QCursor(Qt.PointingHandCursor))
            if group[i] in self.images_to_be_removed:
                self.imageItems[i][4].setStyleSheet('background: #88ffffff; border-radius: 15px;')
                self.imageItems[i][3].toggle()
            else:
                self.imageItems[i][4].setStyleSheet('background: #00000000; border-radius: 15px;')
            self.imageItems[i][3].stateChanged.connect(
                eval(f'lambda event: widget.add_to_delete_list("{group[j]}", {i})'))
            self.flowLayout.addWidget(self.imageItems[i][0])
            self.imageItems[i][3].setGeometry(self.images[i].width() - 30, self.images[i].height() - 125,
                                              self.images[i].width() - 10, self.images[i].height() - 90)

            rect = self.imageItems[i][2].geometry()
            rect.setLeft(6)
            rect.setTop(6)
            rect.setHeight(self.images[i].height())
            rect.setWidth(self.images[i].width())

            self.imageItems[i][4].setGeometry(rect)
            print(f'{group[i]} added')
            i += 1
        for i in reversed(range(self.toggle_group_btn_container_layout.count())):
            self.toggle_group_btn_container_layout.itemAt(i).widget().setEnabled(True)
        self.update()

    def click_on_image(self, f_name, i, event):
        if event.button() == Qt.LeftButton:
            self.imageItems[i][3].toggle()
        elif event.button() == Qt.RightButton:
            print(self.main.geometry())
            self.main_image = QPixmap(f_name)
            self.main_image_lbl_container.show()
            self.main_image_lbl_container.raise_()
            self.main_image_close.raise_()
            self.main_image_size = [self.main_image.width(), self.main_image.height()]
            if self.main_image.width() > self.main_image_lbl_container.width() - 20 or self.main_image.height() > self.main_image_lbl_container.height() - 20:
                self.main_image = self.main_image.scaled(self.main_image_lbl_container.width() - 20,
                                                         self.main_image_lbl_container.height() - 20,
                                                         aspectRatioMode=Qt.KeepAspectRatio)
            self.main_image_lbl.setPixmap(self.main_image)
            self.check_resize_flag = True
            self.main_image_last_size = [self.main_image.width(), self.main_image.height()]
            rect = QRect(0, 0, 0, 0)
            rect.setTop(15)
            rect.setLeft(self.main_image_lbl_container.width() - 89)
            rect.setWidth(74)
            rect.setHeight(74)
            self.main_image_close.setGeometry(rect)

            print(self.main_image_close.geometry(), self.main_image_lbl_container.width(),
                  self.main_image_lbl_container.height())
            self.main_image_name = f_name

    def resizeEvent(self, a0: QResizeEvent) -> None:
        self.main_image_lbl_container.setGeometry(self.main.geometry())
        if self.check_resize_flag:
            rect = QRect(0, 0, 0, 0)
            rect.setTop(15)
            rect.setLeft(self.main_image_lbl_container.width() - 89)
            rect.setWidth(74)
            rect.setHeight(74)
            self.main_image_close.setGeometry(rect)
            x = self.main_image_last_size[0]
            y = self.main_image_last_size[1]
            x1 = self.main_image_lbl_container.width() - 20
            y1 = self.main_image_lbl_container.height() - 20
            if not (x >= self.main_image_size[0] and y >= self.main_image_size[1] and x1 >= self.main_image_size[0] and y1 >= self.main_image_size[1]) and \
                    ((y1 != y and x1 != x) or
                     (y1 == y and x1 < x) or
                     (y1 < y and x1 == x)):
                self.main_image = QPixmap(self.main_image_name).scaled(min(self.main_image_lbl_container.width() - 20, self.main_image_size[0]),
                                                                       min(self.main_image_lbl_container.height() - 20, self.main_image_size[1]),
                                                                       aspectRatioMode=Qt.KeepAspectRatio)
                self.main_image_last_size = [self.main_image.width(), self.main_image.height()]
                self.main_image_lbl.setPixmap(self.main_image)

    def add_to_delete_list(self, f_name, i):
        if f_name not in self.images_to_be_removed:
            widget.images_to_be_removed.append(f_name)
            self.imageItems[i][4].setStyleSheet('background: #88ffffff; border-radius: 15px;')
        else:
            widget.images_to_be_removed.remove(f_name)
            self.imageItems[i][4].setStyleSheet('background: #00ffffff; border-radius: 15px;')
        print(self.images_to_be_removed)

    def find_similary(self, directory, test=False):
        print('in find_similary')
        if test:
            print('find_similary in test-mode')
            self.similar_images = {'/home/sasha/Projects/ImageUtility/images/DSCN0395.JPG': [
                '/home/sasha/Projects/ImageUtility/images/DSCN0395.JPG',
                '/home/sasha/Projects/ImageUtility/images/3.jpeg'],
                '/home/sasha/Projects/ImageUtility/images/DSCN0389.JPG': [
                    '/home/sasha/Projects/ImageUtility/images/DSCN0389.JPG'],
                '/home/sasha/Projects/ImageUtility/images/DSCN0401.JPG': [
                    '/home/sasha/Projects/ImageUtility/images/DSCN0401.JPG'],
                '/home/sasha/Projects/ImageUtility/images/DSCN0384.JPG': [
                    '/home/sasha/Projects/ImageUtility/images/DSCN0384.JPG'],
                '/home/sasha/Projects/ImageUtility/images/DSCN0403.JPG': [
                    '/home/sasha/Projects/ImageUtility/images/DSCN0403.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0404.JPG'],
                '/home/sasha/Projects/ImageUtility/images/DSCN0378.JPG': [
                    '/home/sasha/Projects/ImageUtility/images/DSCN0378.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0379.JPG'],
                '/home/sasha/Projects/ImageUtility/images/DSCN0372.JPG': [
                    '/home/sasha/Projects/ImageUtility/images/DSCN0372.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0376.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0374.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0377.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0369.JPG',
                    '/home/sasha/Projects/ImageUtility/images/DSCN0373.JPG']}
            return
        import numpy as np
        from keras.applications.vgg16 import VGG16
        from keras.applications.vgg16 import preprocess_input
        from keras.models import Model
        from keras.preprocessing import image
        from sklearn.neighbors import NearestNeighbors
        bm = VGG16(weights='imagenet')
        model = Model(inputs=bm.input, outputs=bm.get_layer('fc1').output)

        vectors = []
        filenames = []
        for parent, dirs, files in walk(directory):
            for file in files:
                if file.split('.')[-1].lower() not in ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'pict', 'ico', 'svg']:
                    continue
                img = image.load_img(join_path(parent, file), target_size=(224, 224))  # чтение из файла
                x = image.img_to_array(img)  # сырое изображения в вектор
                x = np.expand_dims(x, axis=0)  # превращаем в вектор-строку (2-dims)
                x = preprocess_input(x)  # библиотечная подготовка изображения
                vectors.append(model.predict(x).ravel())
                filenames.append(join_path(parent, file))

        if len(vectors) == 0:
            self.similar_images = []
            return

        knn = NearestNeighbors(metric='cosine', algorithm='brute')
        knn.fit(vectors)
        dist, indices = knn.radius_neighbors(vectors, radius=0.35)
        self.similar_images = dict((filenames[j], [filenames[indices[j][i]] for i in range(len(indices[j]))]) for j in
                                   range(len(indices)))

    def delete_selected(self):
        dlg = QMessageBox()
        dlg.setWindowTitle('Подтвердите удаление')
        dlg.setText("Удалить " + str(len(self.images_to_be_removed)) + " выбранных файлов?")
        dlg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        dlg.setIcon(QMessageBox.Question)
        button = dlg.exec()
        if button != QMessageBox.Yes:
            return
        for i in self.images_to_be_removed:
            os.remove(i)
        print(f'Deleted files: {self.images_to_be_removed}')
        self.images_screen.hide()
        self.first_screen.show()
        dlg.setWindowTitle('Успешно!')
        dlg.setText("Успешно удалено " + str(len(self.images_to_be_removed)) + " выбранных файлов")
        dlg.setStandardButtons(QMessageBox.Ok)
        dlg.setIcon(QMessageBox.Information)
        dlg.exec()
        self.images_to_be_removed = []


app = QApplication([])
widget = App()
widget.resize(800, 600)
widget.show()
sys.exit(app.exec())
