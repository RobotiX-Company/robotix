pip install tensorflow
pip install PIL
pip install thread6
pip install PyQt5
